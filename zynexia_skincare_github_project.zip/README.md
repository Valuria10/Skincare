# ZYNEXIA Skincare KI

Dies ist eine KI-gestützte Hautanalyse-Plattform mit GPT-4 Vision und Fragebogen.

## Start (lokal)
```bash
pip install -r requirements.txt
streamlit run app/skin_analysis.py
```

## Struktur
- `app/skin_analysis.py` – KI-Hautanalyse per Bild & Fragebogen
- `app/main.py` – Flask API + Scheduler (optional)

## Deployment
Empfohlen: [Render.com](https://render.com) oder [Streamlit Cloud](https://streamlit.io/cloud)